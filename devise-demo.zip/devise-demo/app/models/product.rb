class Product < ApplicationRecord
  monetize :rate_cents, allow_nil: true,numericality:{
    greater_than_or_equal_to: 0}
end
