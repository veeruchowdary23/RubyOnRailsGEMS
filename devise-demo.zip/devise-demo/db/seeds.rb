# This file should ensure the existence of records required to run the application in every environment (production,
# development, test). The code here should be idempotent so that it can be executed at any point in every environment.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Example:
#
#   ["Action", "Comedy", "Drama", "Horror"].each do |genre_name|
#     MovieGenre.find_or_create_by!(name: genre_name)
#   end


User.create!(email:"test1@gmail.com",password:'Krify@123456')
User.create!(email:"test2@gmail.com",password:'Krify@123456')

Product.create!(name: "Movie", rate: Money.new(7600,'EUR'))
Product.create!(name: "Book", rate: Money.new(8000,'USD'))


# 100.times do
#   User.create!(email: Faker::Internet.email, password:Faker:: Internet.password(min_length: 6))
# end

# 100.times do
#   Product.create!(name: Faker::Team.name)
# end
