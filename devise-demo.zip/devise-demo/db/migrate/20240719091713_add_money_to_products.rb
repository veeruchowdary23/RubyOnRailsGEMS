class AddMoneyToProducts < ActiveRecord::Migration[7.1]
  def change
    add_monetize :products, :rate
  end
end
